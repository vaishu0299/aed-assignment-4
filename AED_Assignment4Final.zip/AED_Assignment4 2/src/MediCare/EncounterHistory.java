/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;
import MediCare.Person;
import MediCare.PersonDirectory;

import java.util.ArrayList;

/**
 *
 * @author vaishnavisai
 */
public class EncounterHistory {
    private ArrayList<Encounter> EList;
     
    public EncounterHistory(){
        this.EList=new ArrayList<Encounter>();  
        
    }

    public ArrayList<Encounter> getEList() {
        return EList;
    }

    public void setEList(ArrayList<Encounter> EList) {
        this.EList = EList;
    }
    
    public Encounter addNewEncounter() {
        Encounter newEnc = new Encounter();
        EList.add(newEnc);
        return newEnc;
    }
    public void deleteCab(Encounter selectedEnc) {
        EList.remove(selectedEnc);
    }
    
}
