/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

import java.util.ArrayList;

/**
 *
 * @author vaishnavisai
 */
public class PatientDirectory {
     public ArrayList<Patient> PtList;

    public ArrayList<Patient> getPtList() {
        return PtList;
    }

    public void setPtList(ArrayList<Patient> PtList) {
        this.PtList = PtList;
    }
    
    public PatientDirectory(){
        this.PtList=new ArrayList<Patient>();      
    }

    public Patient addNewPatient() {
        Patient newPt = new Patient();
        PtList.add(newPt);
        return newPt;
    }

    public void deleteCab(Patient selectedPatient) {
        PtList.remove(selectedPatient);
    }
    
}
