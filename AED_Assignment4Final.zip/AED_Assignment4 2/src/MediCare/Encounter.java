/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package MediCare;

import java.util.Date;

/**
 *
 * @author vaishnavisai
 */
public class Encounter {
    Patient pt=new Patient();
    Vitalsigns vs=new Vitalsigns();
    String VisitDate;
   

    public String getVisitDate() {
        return VisitDate;
    }

    public void setVisitDate(String VisitDate) {
        this.VisitDate = VisitDate;
    }
    
    public Patient getPt() {
        return pt;
    }

    public void setPt(Patient pt) {
        this.pt = pt;
    }

    public Vitalsigns getVs() {
        return vs;
    }

    public void setVs(Vitalsigns vs) {
        this.vs = vs;
    }
     @Override
    public String toString(){
        return String.valueOf(pt.getPid());
    }
    
    
}
